import React, {useState, useEffect} from "react";
import Prueba from './Prueba';
import './App.css';
const Seve_Days = () => {
  return(
    <div className="App">
      <header className="App-header">
        <Prueba/>
      </header>
    </div>
  )
}


export default Seve_Days;